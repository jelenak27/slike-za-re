/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextBrowser>
#include "grafwidget.h"

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QGridLayout *gridLayout;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_3;
    QLabel *label_6;
    QLabel *labelDanNoc;
    QLabel *labelLedTemp;
    QLabel *label_11;
    QLabel *labelLedKretanje;
    QLabel *label_5;
    QLabel *label_7;
    QLabel *labelKretanje;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_5;
    GrafWidget *grafWidget;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_4;
    QTextBrowser *textBrowserIspis;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QLCDNumber *lcdTemp;
    QLabel *label_2;
    QLCDNumber *lcdVlaznost;
    QLabel *label_3;
    QSpinBox *spinBoxPrag;
    QPushButton *pushButtonPostavi;
    QLabel *label_4;
    QLabel *labelStatus;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(800, 600);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Dialog->sizePolicy().hasHeightForWidth());
        Dialog->setSizePolicy(sizePolicy);
        Dialog->setStyleSheet(QString::fromUtf8("QDialog {\n"
"    background-color: #f0f0f0;\n"
"}\n"
"\n"
"QGroupBox {\n"
"    border: 2px solid #b0b8c8;\n"
"    border-radius: 6px;\n"
"    margin-top: 10px;\n"
"    padding-top: 6px;\n"
"    font-weight: bold;\n"
"    color: #2c5f9e;\n"
"    font-size: 11px;\n"
"}\n"
"\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    subcontrol-position: top left;\n"
"    left: 8px;\n"
"    padding: 0 4px;\n"
"    background-color: #f0f0f0;\n"
"}\n"
"\n"
"QLabel {\n"
"    font-size: 12px;\n"
"    color: #222222;\n"
"}\n"
"\n"
"QLCDNumber {\n"
"    background-color: #ddeedd;\n"
"    color: #1a5c1a;\n"
"    border: 1px solid #999;\n"
"    border-radius: 3px;\n"
"}\n"
"\n"
"QPushButton {\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,\n"
"        stop:0 #f0f0f0, stop:1 #d8d8d8);\n"
"    border: 1px solid #999;\n"
"    border-radius: 4px;\n"
"    padding: 4px 14px;\n"
"    font-size: 12px;\n"
"    color: #222;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background: #d0e0f0;\n"
"    border-color: #5a"
                        "80b0;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background: #b8cce0;\n"
"}\n"
"\n"
"QProgressBar {\n"
"    border: 1px solid #aaa;\n"
"    border-radius: 3px;\n"
"    text-align: right;\n"
"    padding-right: 4px;\n"
"    background: #e8e8e8;\n"
"    font-size: 11px;\n"
"    color: #333;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 #e08800, stop:1 #f5c000);\n"
"    border-radius: 2px;\n"
"}\n"
"\n"
"QSpinBox {\n"
"    border: 1px solid #aaa;\n"
"    border-radius: 3px;\n"
"    padding: 2px 4px;\n"
"    background: white;\n"
"    font-size: 12px;\n"
"}"));
        gridLayout = new QGridLayout(Dialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        groupBox_2 = new QGroupBox(Dialog);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox_2->sizePolicy().hasHeightForWidth());
        groupBox_2->setSizePolicy(sizePolicy1);
        groupBox_2->setMinimumSize(QSize(0, 200));
        gridLayout_3 = new QGridLayout(groupBox_2);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_3->addWidget(label_6, 1, 0, 1, 1);

        labelDanNoc = new QLabel(groupBox_2);
        labelDanNoc->setObjectName(QString::fromUtf8("labelDanNoc"));

        gridLayout_3->addWidget(labelDanNoc, 0, 1, 1, 1);

        labelLedTemp = new QLabel(groupBox_2);
        labelLedTemp->setObjectName(QString::fromUtf8("labelLedTemp"));
        labelLedTemp->setPixmap(QPixmap(QString::fromUtf8(":/slike/led_temp_off.png")));
        labelLedTemp->setScaledContents(false);

        gridLayout_3->addWidget(labelLedTemp, 2, 1, 1, 1);

        label_11 = new QLabel(groupBox_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_3->addWidget(label_11, 3, 0, 1, 1);

        labelLedKretanje = new QLabel(groupBox_2);
        labelLedKretanje->setObjectName(QString::fromUtf8("labelLedKretanje"));
        labelLedKretanje->setPixmap(QPixmap(QString::fromUtf8(":/slike/led_kretanje_off.png")));

        gridLayout_3->addWidget(labelLedKretanje, 3, 1, 1, 1);

        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_3->addWidget(label_5, 0, 0, 1, 1);

        label_7 = new QLabel(groupBox_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_3->addWidget(label_7, 2, 0, 1, 1);

        labelKretanje = new QLabel(groupBox_2);
        labelKretanje->setObjectName(QString::fromUtf8("labelKretanje"));
        labelKretanje->setPixmap(QPixmap(QString::fromUtf8(":/slike/kretanje_ne.png")));
        labelKretanje->setScaledContents(false);

        gridLayout_3->addWidget(labelKretanje, 1, 1, 1, 1);


        gridLayout->addWidget(groupBox_2, 0, 1, 1, 1);

        groupBox_4 = new QGroupBox(Dialog);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setMinimumSize(QSize(0, 300));
        gridLayout_5 = new QGridLayout(groupBox_4);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        grafWidget = new GrafWidget(groupBox_4);
        grafWidget->setObjectName(QString::fromUtf8("grafWidget"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(grafWidget->sizePolicy().hasHeightForWidth());
        grafWidget->setSizePolicy(sizePolicy2);

        gridLayout_5->addWidget(grafWidget, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_4, 1, 1, 1, 1);

        groupBox_3 = new QGroupBox(Dialog);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setMinimumSize(QSize(0, 300));
        groupBox_3->setStyleSheet(QString::fromUtf8("QDialog {\n"
"    background-color: #f0f0f0;\n"
"}\n"
"\n"
"QGroupBox {\n"
"    border: 2px solid #b0b8c8;\n"
"    border-radius: 6px;\n"
"    margin-top: 10px;\n"
"    padding-top: 6px;\n"
"    font-weight: bold;\n"
"    color: #2c5f9e;\n"
"    font-size: 11px;\n"
"}\n"
"\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    subcontrol-position: top left;\n"
"    left: 8px;\n"
"    padding: 0 4px;\n"
"    background-color: #f0f0f0;\n"
"}\n"
"\n"
"QLabel {\n"
"    font-size: 12px;\n"
"    color: #222222;\n"
"}\n"
"\n"
"QLCDNumber {\n"
"    background-color: #ddeedd;\n"
"    color: #1a5c1a;\n"
"    border: 1px solid #999;\n"
"    border-radius: 3px;\n"
"}\n"
"\n"
"QPushButton {\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,\n"
"        stop:0 #f0f0f0, stop:1 #d8d8d8);\n"
"    border: 1px solid #999;\n"
"    border-radius: 4px;\n"
"    padding: 4px 14px;\n"
"    font-size: 12px;\n"
"    color: #222;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background: #d0e0f0;\n"
"    border-color: #5a"
                        "80b0;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background: #b8cce0;\n"
"}\n"
"\n"
"QProgressBar {\n"
"    border: 1px solid #aaa;\n"
"    border-radius: 3px;\n"
"    text-align: right;\n"
"    padding-right: 4px;\n"
"    background: #e8e8e8;\n"
"    font-size: 11px;\n"
"    color: #333;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 #e08800, stop:1 #f5c000);\n"
"    border-radius: 2px;\n"
"}\n"
"\n"
"QSpinBox {\n"
"    border: 1px solid #aaa;\n"
"    border-radius: 3px;\n"
"    padding: 2px 4px;\n"
"    background: white;\n"
"    font-size: 12px;\n"
"}"));
        gridLayout_4 = new QGridLayout(groupBox_3);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        textBrowserIspis = new QTextBrowser(groupBox_3);
        textBrowserIspis->setObjectName(QString::fromUtf8("textBrowserIspis"));

        gridLayout_4->addWidget(textBrowserIspis, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_3, 1, 0, 1, 1);

        groupBox = new QGroupBox(Dialog);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        sizePolicy1.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy1);
        groupBox->setMinimumSize(QSize(0, 200));
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        lcdTemp = new QLCDNumber(groupBox);
        lcdTemp->setObjectName(QString::fromUtf8("lcdTemp"));

        gridLayout_2->addWidget(lcdTemp, 0, 1, 1, 2);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 1, 0, 1, 1);

        lcdVlaznost = new QLCDNumber(groupBox);
        lcdVlaznost->setObjectName(QString::fromUtf8("lcdVlaznost"));

        gridLayout_2->addWidget(lcdVlaznost, 1, 1, 1, 2);

        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_2->addWidget(label_3, 2, 0, 1, 2);

        spinBoxPrag = new QSpinBox(groupBox);
        spinBoxPrag->setObjectName(QString::fromUtf8("spinBoxPrag"));

        gridLayout_2->addWidget(spinBoxPrag, 2, 2, 1, 1);

        pushButtonPostavi = new QPushButton(groupBox);
        pushButtonPostavi->setObjectName(QString::fromUtf8("pushButtonPostavi"));

        gridLayout_2->addWidget(pushButtonPostavi, 2, 3, 1, 1);

        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_2->addWidget(label_4, 3, 0, 1, 1);

        labelStatus = new QLabel(groupBox);
        labelStatus->setObjectName(QString::fromUtf8("labelStatus"));
        labelStatus->setPixmap(QPixmap(QString::fromUtf8(":/slike/status_ispod.png")));
        labelStatus->setScaledContents(false);

        gridLayout_2->addWidget(labelStatus, 3, 1, 1, 1);


        gridLayout->addWidget(groupBox, 0, 0, 1, 1);


        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("Dialog", "Okolina", nullptr));
        label_6->setText(QCoreApplication::translate("Dialog", "Kretanje:", nullptr));
        labelDanNoc->setText(QString());
        labelLedTemp->setText(QString());
        label_11->setText(QCoreApplication::translate("Dialog", "LED  Kretanje", nullptr));
        labelLedKretanje->setText(QString());
        label_5->setText(QCoreApplication::translate("Dialog", "Dan/Noc:", nullptr));
        label_7->setText(QCoreApplication::translate("Dialog", "LED Temp", nullptr));
        labelKretanje->setText(QString());
        groupBox_4->setTitle(QCoreApplication::translate("Dialog", "Temperatura-graf", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("Dialog", "Ispis merenja", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Dialog", "Senzori", nullptr));
        label->setText(QCoreApplication::translate("Dialog", "Temp:", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog", "Vlaznost:", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog", "Prag Temperature:", nullptr));
        pushButtonPostavi->setText(QCoreApplication::translate("Dialog", "Postavi", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog", "Status:", nullptr));
        labelStatus->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
